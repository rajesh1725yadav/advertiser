import React, {useEffect, useState } from "react";
import UserAvatar from "../../../user/UserAvatar";
import { activityData } from "./ActivityData";
import { Badge, CardTitle } from "reactstrap";
import { getNotification } from "../../../../app/api";
import Loader from "../../../../app/Loader";
import { Icon } from "../../../Component";
import Moment from "react-moment";

const RecentActivity = () => {

  const [recentUser, setRecentUser] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const getNoti = async () => {
    
    setLoading(true);
    let res = await getNotification();
    
    if(res.code === 200) {
      setData(res.data);
    }
    // console.log(res.data);
    setLoading(false);
  }
  
  useEffect(()=> {
    getNoti();
  }, []);
  
  return (
    <React.Fragment>
      <Loader visible={loading} />
      <div className="card-inner border-bottom">
        <div className="card-title-group">
          <CardTitle>
            <h6 className="title">Recent Notification <Icon name="fa fa-user" /></h6>
          </CardTitle>
        </div> 
      </div>
      <ul className="nk-activity">
        {data !== null 
          ? data.map((item, key) => {
            let cls = (item.noti_type == 1) ? 'nk-activity-item sm-bg-light' : 'nk-activity-item';
            let tag = (item.noti_type == 2) ? <Badge pill color="danger">New</Badge> : '';
              return ( 
                <li className={cls} key={key}>
                  {item.noti_type == 1 ? 
                  <UserAvatar
                    className="nk-activity-media"
                    theme="primary"
                    image={item.img}
                    text={item.initial}
                  >
                  <Icon name="bell" style={{fontSize:20}} />
                  </UserAvatar>
                  :
                  <UserAvatar
                      className="nk-activity-media" 
                      theme="warning" 
                      image={item.img} 
                      text={item.initial} 
                    >
                    <Icon name="percent" style={{fontSize:20}} />
                  </UserAvatar>
                }
                  <div className="nk-activity-data">
                    <div className="label">{item.title} &nbsp; {tag}</div>
                    <span className="time"><Moment fromNow >{item.created_at}</Moment></span>
                  </div>
                </li>
              );
            })
          : null}
      </ul>
    </React.Fragment>
  );
};
export default RecentActivity;
