import React, { useState } from "react";
import { SessionDoughnut, SessionOsDoughnut } from "../../charts/analytics/AnalyticsCharts";
import { DropdownToggle, DropdownMenu, UncontrolledDropdown, DropdownItem } from "reactstrap";
import { Icon } from "../../../Component";

const SessionOs = ({osData}) => {
  console.log(osData)
  const [sessionDevice, setSessionDevices] = useState("30");
  return (
    <React.Fragment>
      <div className="card-title-group">
        <div className="card-title card-title-sm">
          <h6 className="title">Traffic by Oprating System</h6>
        </div>
      </div>
      <div className="device-status my-auto">
        <div className="device-status-ck">
          <SessionOsDoughnut className="analytics-doughnut" state={osData} />
        </div>
        <div className="device-status-group">
          <div className="device-status-data">
            <Icon style={{ color: "#0377D0" }} name="windows"></Icon>
            <div className="title">Windows</div>
            <div className="amount"> {osData.windows.percent}%</div>
            <div className="change up text-danger">
              {/* <Icon name="arrow-long-up"></Icon> */}
              {/* {sessionDevice === "7" ? "2.5" : sessionDevice === "15" ? "4.5" : "10.5"}% */}
            </div>
          </div>
          <div className="device-status-data">
            <Icon style={{ color: "#000000" }} name="apple"></Icon>
            <div className="title">Apple</div>
            <div className="amount"> {osData.apple.percent}%</div>
            <div className="change up text-danger">
              {/* <Icon name="arrow-long-up"></Icon> */}
              {/* {sessionDevice === "7" ? "12.5" : sessionDevice === "15" ? "114.5" : "110.5"}% */}
            </div>
          </div>
          <div className="device-status-data">
            <Icon style={{ color: "#3BD482" }} name="android"></Icon>
            <div className="title">Android</div>
            <div className="amount"> {osData.android.percent}%</div>
            <div className="change up text-danger">
              {/* <Icon name="arrow-long-up"></Icon> */}
              {/* {sessionDevice === "7" ? "25.5" : sessionDevice === "15" ? "14.5" : "15.5"}% */}
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};
export default SessionOs;
