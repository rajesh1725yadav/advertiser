import React, { useState } from "react";
import { SessionDoughnut } from "../../charts/analytics/AnalyticsCharts";
import { DropdownToggle, DropdownMenu, UncontrolledDropdown, DropdownItem } from "reactstrap";
import { Icon } from "../../../Component";

const SessionDevice = ({dvData}) => {
  console.log(dvData)
  const [sessionDevice, setSessionDevices] = useState("30");
  return (
    <React.Fragment>
      <div className="card-title-group">
        <div className="card-title card-title-sm">
          <h6 className="title">Traffic by devices</h6>
        </div>
      </div>
      <div className="device-status my-auto">
        <div className="device-status-ck">
          <SessionDoughnut className="analytics-doughnut" state={dvData} />
        </div>
        <div className="device-status-group">
          <div className="device-status-data">
            <Icon style={{ color: "#798bff" }} name="monitor"></Icon>
            <div className="title">Desktop</div>
            <div className="amount"> {dvData.desktop.percent}%</div>
            <div className="change up text-danger">
              {/* <Icon name="arrow-long-up"></Icon> */}
              {/* {sessionDevice === "7" ? "2.5" : sessionDevice === "15" ? "4.5" : "10.5"}% */}
            </div>
          </div>
          <div className="device-status-data">
            <Icon style={{ color: "#baaeff" }} name="mobile"></Icon>
            <div className="title">Mobile</div>
            <div className="amount"> {dvData.mobile.percent}%</div>
            <div className="change up text-danger">
              {/* <Icon name="arrow-long-up"></Icon> */}
              {/* {sessionDevice === "7" ? "12.5" : sessionDevice === "15" ? "114.5" : "110.5"}% */}
            </div>
          </div>
          <div className="device-status-data">
            <Icon style={{ color: "#7de1f8" }} name="tablet"></Icon>
            <div className="title">Tablet</div>
            <div className="amount"> {dvData.tablet.percent}%</div>
            <div className="change up text-danger">
              {/* <Icon name="arrow-long-up"></Icon> */}
              {/* {sessionDevice === "7" ? "25.5" : sessionDevice === "15" ? "14.5" : "15.5"}% */}
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};
export default SessionDevice;
